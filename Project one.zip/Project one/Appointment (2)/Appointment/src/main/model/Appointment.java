package main.model;
import java.util.Date;

public class Appointment {
	
	//constants for validation
	private static final int MAX_APPOINTMENTID_LENGTH = 10;
	private static final int MAX_APPOINTMENTDESCRIPTION_LENGTH = 50;
	
	//Attributes
	private final String appointmentId; //Not to be updated
	private Date appointmentDate;
	private String appointmentDescription;

	
	//Constructor
	public Appointment(String appointmentId, Date appointmentDate, String appointmentDescription) {
		this.appointmentId = validateId(appointmentId);
		this.appointmentDate = validateDate(appointmentDate);
		this.appointmentDescription = validateDescription(appointmentDescription);
	}
	
	//getters
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	
	//Setters with validation (excluding appointment Id)
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = validateDate(appointmentDate);
	}
	public void setAppointmentDescription(String appointmentDescription){
		this.appointmentDescription= validateDescription(appointmentDescription);
	}
	
	//private helper methods for validation
	private String validateId(String appointmentId) {
		if (appointmentId == null) {
		//exception given if requirements are not met
			throw new IllegalArgumentException("Appointment Id must not be null.");
		}
		
		if(appointmentId.length() > MAX_APPOINTMENTID_LENGTH) {
			throw new IllegalArgumentException("Appointment Id must not be longer than 10 characters.");
		}
		return appointmentId;
	}
	
	private Date validateDate(Date appointmentDate) {
		if (appointmentDate == null) {
			//exception given if requirements are not met
			throw new IllegalArgumentException("Appointment date must not be null.");
		}
		if(appointmentDate.before(new Date())) {
		    throw new IllegalArgumentException("Appointment date must not be in the past or null.");
		}
		return appointmentDate;
	}
	
	private String validateDescription (String appointmentDescription) {
		if (appointmentDescription == null) {
			throw new IllegalArgumentException("Appointment description must not be null.");
		}
		if (appointmentDescription.length() > MAX_APPOINTMENTDESCRIPTION_LENGTH) {
			throw new IllegalArgumentException("Appointment Description must not be longer than 50 characters.");
		}
		return appointmentDescription;
	}

}
