package main.model;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	
	//hashmap to store appointment info(Key: appointmentId, value: appointment object)
	private Map<String, Appointment> appointmentMap = new HashMap<>();
	
	//method to add a new appointment
	public void addAppointment(Appointment appointment) {
		//if statement to verify input meets requirements
		if(appointmentMap.containsKey(appointment.getAppointmentId())) {
			throw new IllegalArgumentException("Appointment Id already exists.");
		}
		//if requirements are met
		appointmentMap.put(appointment.getAppointmentId(), appointment);
	}
	
	//method to delete appointment
	public void deleteAppointment(String appointmentId) {
		if(!appointmentMap.containsKey(appointmentId)) {
			throw new IllegalArgumentException("Appointment Id not found.");
		}
		appointmentMap.remove(appointmentId);
	}
}
