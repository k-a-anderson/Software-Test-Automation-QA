package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import main.model.Appointment;
import main.model.AppointmentService;

class AppointmentServiceTest {

	@Test
	//test for adding appointment successfully
	void testAddAppointmentSuccessfully() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		
		service.addAppointment(appointment);
	}

	@Test
	//test for adding appointment with duplicate ID
	void testAddAppointmentDuplicateId() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		Appointment appointment1 = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		Appointment appointment2 = new Appointment("1234567890", futureDate, "This is an example appointment description.");

		service.addAppointment(appointment1);
		assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(appointment2);
		}, "Expected an exception when adding an appointment with a duplicate ID.");
	}

	@Test
	//test for deleting appointment successfully
	void testDeleteAppointmentSuccessfully() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		
		service.addAppointment(appointment);
		service.deleteAppointment("1234567890");
	}

	@Test
	//test for deleting appointment with invalid ID
	void testDeleteAppointmentInvalidId() {
		AppointmentService service = new AppointmentService();
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteAppointment("invalid_id");
		}, "Expected an exception when deleting an appointment with an invalid ID.");
	}
}
