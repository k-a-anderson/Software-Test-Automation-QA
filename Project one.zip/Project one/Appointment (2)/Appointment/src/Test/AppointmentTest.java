package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.model.Appointment;

import java.util.Date;

class AppointmentTest {
	
	//Tests for Appointment Id
	@Test
	//test for null appointment Id
	void testAppointmentIdNull() {
		//create a future date (current time + 1 day)
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (null,futureDate, "This is an example appointment description.");
		}, "Expected an exception when using a null Appointment Id.");
	}
	
	@Test
	//test for valid appointment id 
	void testValidNewAppointmentId() {
		//create a future date (current time + 1 day)
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		assertEquals ("1234567890", appointment.getAppointmentId());
	}
	
	@Test 
	//test for appointmentId exceeding length
	void testAppointmentIdTooLong() {
		//create a future date (current time + 1 day)
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
				
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678900", futureDate, "This is an example appointment description.");
		}, "Expected an exception when using entering a Appointment Id with more than 10 characters.");
	}
	
	//Tests for Appointment Date
	
	@Test
	//test for appointment date
	void testValidNewAppointmentDate() {
		//create a future date (current time + 1 day)
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
	
		assertEquals (futureDate, appointment.getAppointmentDate());
	}
	
	@Test
	//test for null date
	void testNullAppointmentDate() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", null, "This is an example appointment description.");
		}, "Expected an exception when entering a Null Appointment Date.");	
	}
	
	@Test
	//test for past date
	void testPastAppointmentDate() {
		Date pastDate = new Date(System.currentTimeMillis()- 86400000);//1 day in past
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", pastDate,"This is an example appointment description." );
		}, "Expected an exception when entering an Appointment Date in the past.");
	}
	//Tests for Appointment Description
	
	@Test
	//test for appointment description
	void testValidNewAppointmentDescription() {
		//create a future date (current time + 1 day)
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		assertEquals ("This is an example appointment description.", appointment.getAppointmentDescription());
	}
	
	@Test
	//test for appointment description being null
	void testNullAppointmentDescription() {
		//create a future date (current time + 1 day)
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
						
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", futureDate, null);
		}, "Expected an exception when using entering a null Appointment Description.");
	}
	
	@Test
	//test for appointment description exceeding length
	void testAppointmentDescriptionTooLong() {
		//create a future date (current time + 1 day)
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
								
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", futureDate,"This is an example appointment description. This is an example appointment description." );
		}, "Expected an exception when using entering an Appointment Description over 50 characters.");
	}
	
	//Setters Tests
	@Test
	//test for setting Appointment Date Successfully
	void testSetAppointmentDateSuccessfully() {
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		Date testFutureDate = new Date(System.currentTimeMillis()+ 172800000);//2 days in ms
		
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		appointment.setAppointmentDate(testFutureDate);
		assertEquals(testFutureDate, appointment.getAppointmentDate());
	}
	
	@Test
	//test for setting Appointment Date to Null
	void testSetAppointmentDateNull() {
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		assertThrows(IllegalArgumentException.class, () -> {
	        appointment.setAppointmentDate(null);
	    },"Expected an exception when setting Appointment date to null");
	}
	
	@Test
	//test for setting Appointment Date in the Past
	void testSetAppointmentDatePast() {
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		
		Date pastDate = new Date(System.currentTimeMillis()- 86400000);//1 day in past
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setAppointmentDate(pastDate);
		}, "Expected an exception when entering an Appointment Date in the past.");
		
	}
	
	@Test
	//test for setting Appointment Description successfully
	void testSetAppointmentDescriptionSuccessfully() {
		Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
	
		Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
		appointment.setAppointmentDescription("Updated Appointment Description.");
		assertEquals("Updated Appointment Description.", appointment.getAppointmentDescription());
	}
	
	@Test
	//test for setting Appointment Description to Null
		void testSetAppointmentDescriptionNull() {
			Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
			
			Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
			assertThrows(IllegalArgumentException.class, () -> {
		        appointment.setAppointmentDescription(null);
		    },"Expected an exception when setting Appointment description to null");
		}
	
	@Test
	//test for setting Appointment Description Too Long
		void testSetAppointmentDescriptionTooLong() {
			Date futureDate = new Date(System.currentTimeMillis()+ 86400000);//1 day in ms
			
			Appointment appointment = new Appointment("1234567890", futureDate, "This is an example appointment description.");
			assertThrows(IllegalArgumentException.class, () -> {
		        appointment.setAppointmentDescription("This is an example appointment description. This is an example appointment description.");
		    },"Expected an exception when updating Appointment Description over 50 characters.");
		}
	
}
