package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.contact.Contact;
import main.contact.ContactService;


class ContactServiceTest {

	@Test
	void testAddContactSuccessfully() {
		ContactService service = new ContactService();
		// add test contacts
		Contact contact1 = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		Contact contact2 = new Contact("1232", "Cory", "Anderson", "1234567898", "1234 Smith Ave");

		service.addContact(contact1);

		// Test for Duplicate ID when creating a new contact
		assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(contact2);
		}, "Expected an exception when adding duplicate contact ID.");

	}

	@Test
	void testDeleteContactSuccessfully() {
		ContactService service = new ContactService();
		Contact contact1 = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		// Test to delete a contact successfully
		service.addContact(contact1);
		service.deleteContact("1232");
	}

	@Test
	void testDeleteInvalidContact() {
		ContactService service = new ContactService();

		// test if exception is thrown when a nonexistent id is deleted
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteContact("Invalid-Id");
		}, "Expected an exception when deleting an invalid id");
	}

	@Test
	void testUpdateContactSuccessfully() {
		// add test contact
		ContactService service = new ContactService();
		Contact contact1 = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		service.addContact(contact1);
		// update contact
		service.updateContact("1232", "Kortney", "Kingma", "1234567890", "123 Abc Rd");
		// verify contact info has updated correctly
		assertEquals("Kortney", contact1.getFirstName());
		assertEquals("Kingma", contact1.getLastName());
		assertEquals("1234567890", contact1.getPhone());
		assertEquals("123 Abc Rd", contact1.getAddress());
	}
}