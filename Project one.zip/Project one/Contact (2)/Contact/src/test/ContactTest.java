package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.contact.Contact;


class ContactTest {

	// Valid Contact Creation
	@Test
	void testValidContactId() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertEquals("1232", contact.getContactId());
	}

	@Test
	void testValidFirstName() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertEquals("Kaylee", contact.getFirstName());
	}

	@Test
	void testValidLastName() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertEquals("Anderson", contact.getLastName());
	}

	@Test
	void testValidPhone() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertEquals("1234567890", contact.getPhone());
	}

	@Test
	void testValidAddress() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertEquals("123 Abc St", contact.getAddress());
	}

	// Constructor: Invalid inputs

	@Test
	void testContactIdNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Kaylee", "Anderson", "1234567890", "123 Abc St");
		});
	}

	@Test
	void testContactIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		});
	}

	@Test
	void testFirstNameNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", null, "Anderson", "1234567890", "123 Abc St");
		});
	}

	@Test
	void testFirstNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "FirstnameTooLong", "Anderson", "1234567890", "123 Abc St");
		});
	}

	@Test
	void testLastNameNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", null, "1234567890", "123 Abc St");
		});
	}

	@Test
	void testLastNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", "LastNameTooLong", "1234567890", "123 Abc St");
		});
	}

	@Test
	void testPhoneNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", "Anderson", null, "123 Abc St");
		});
	}

	@Test
	void testPhoneTooShort() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", "Anderson", "123456789", "123 Abc St");
		});
	}

	@Test
	void testPhoneTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", "Anderson", "12345678901", "123 Abc St");
		});
	}

	@Test
	void testPhoneNonDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", "Anderson", "12345abcde", "123 Abc St");
		});
	}

	@Test
	void testAddressNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", "Anderson", "1234567890", null);
		});
	}

	@Test
	void testAddressTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1232", "Kaylee", "Anderson", "1234567890",
					"123 This is a very long address that exceeds thirty characters");
		});
	}

	// Setters: First Name

	@Test
	void testSetFirstNameValid() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		contact.setFirstName("Kristen");
		assertEquals("Kristen", contact.getFirstName());
	}

	@Test
	void testSetFirstNameNull() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(null);
		});
	}

	@Test
	void testSetFirstNameTooLong() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("FirstnameTooLong");
		});
	}

	// Setters: Last Name

	@Test
	void testSetLastNameValid() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		contact.setLastName("Kingma");
		assertEquals("Kingma", contact.getLastName());
	}

	@Test
	void testSetLastNameNull() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(null);
		});
	}

	@Test
	void testSetLastNameTooLong() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName("LastNameTooLong");
		});
	}

	// Setters: Phone

	@Test
	void testSetPhoneValid() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		contact.setPhone("0987654321");
		assertEquals("0987654321", contact.getPhone());
	}

	@Test
	void testSetPhoneNull() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone(null);
		});
	}

	@Test
	void testSetPhoneTooShort() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone("123456789");
		});
	}

	@Test
	void testSetPhoneTooLong() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone("12345678901");
		});
	}

	@Test
	void testSetPhoneNonDigits() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone("12345abcde");
		});
	}

	// Setters: Address

	@Test
	void testSetAddressValid() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		contact.setAddress("456 New Rd");
		assertEquals("456 New Rd", contact.getAddress());
	}

	@Test
	void testSetAddressNull() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(null);
		});
	}

	@Test
	void testSetAddressTooLong() {
		Contact contact = new Contact("1232", "Kaylee", "Anderson", "1234567890", "123 Abc St");
		assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress("This address is extremely long and should definitely fail.");
		});
	}
	
	//Edge tests
	@Test
	// Contact ID at exactly 10 characters
	void testContactIdMaxLength() {
	    Contact contact = new Contact("1234567890", "Kaylee", "Anderson", "1234567890", "123 Main St");
	    assertEquals("1234567890", contact.getContactId());
	}

	@Test
	// First name at exactly 10 characters
	void testFirstNameMaxLength() {
	    Contact contact = new Contact("12345", "Firstnames", "Anderson", "1234567890", "123 Main St");
	    assertEquals("Firstnames", contact.getFirstName()); 
	}

	@Test
	// Last name at exactly 10 characters
	void testLastNameMaxLength() {
	    Contact contact = new Contact("12345", "Kaylee", "Lastname10", "1234567890", "123 Main St");
	    assertEquals("Lastname10", contact.getLastName());
	}

	@Test
	// Phone at exactly 10 digits
	void testPhoneMaxLength() {
	    Contact contact = new Contact("12345", "Kaylee", "Anderson", "1234567890", "123 Main St");
	    assertEquals("1234567890", contact.getPhone());
	}

	@Test
	// Address at exactly 30 characters
	void testAddressMaxLength() {
	    Contact contact = new Contact("12345", "Kaylee", "Anderson", "1234567890", "123456789012345678901234567890");
	    assertEquals("123456789012345678901234567890", contact.getAddress());
	}
}
