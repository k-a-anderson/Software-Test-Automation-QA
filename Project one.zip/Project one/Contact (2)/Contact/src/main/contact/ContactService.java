package main.contact;
import java.util.HashMap;
import java.util.Map;

public class ContactService {

	// HashMap to store contact info (key: contactId, value: Contact object)
	private Map<String, Contact> contactMap = new HashMap<>();

	// Method to add a new contact
	public void addContact(Contact contact) {
		// if statement to verify input meets requirements
		if (contactMap.containsKey(contact.getContactId())) {
			throw new IllegalArgumentException("Contact ID already exists.");
		}
		// if it meets requirements
		contactMap.put(contact.getContactId(), contact);
	}

	// Method to delete a contact using a contact ID
	public void deleteContact(String contactId) {
		if (!contactMap.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact ID not found.");
		}
		contactMap.remove(contactId);
	}

	// method to update contact field using contact ID
	public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
		if (!contactMap.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact ID not found.");
		}
		Contact contact = contactMap.get(contactId);
		contact.setFirstName(firstName);
		contact.setLastName(lastName);
		contact.setPhone(phone);
		contact.setAddress(address);
	}
}