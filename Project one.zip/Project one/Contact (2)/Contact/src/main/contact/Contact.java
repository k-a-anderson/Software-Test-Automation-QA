package main.contact;
public class Contact {

	// constants for validation
	private static final int MAX_ID_LENGTH = 10;
	private static final int MAX_NAME_LENGTH = 10;
	private static final int PHONE_LENGTH = 10;
	private static final int MAX_ADDRESS_LENGTH = 30;

	// attributes
	private final String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	// Constructor
	public Contact(String contactId, String firstName, String lastName, String phone, String address) {

		this.contactId = validateId(contactId); // Cannot be updated later
		this.firstName = validateName(firstName, "First Name");
		this.lastName = validateName(lastName, "Last Name");
		this.phone = validatePhone(phone);
		this.address = validateAddress(address);
	}

	// getters
	public String getContactId() {
		return contactId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPhone() {
		return phone;
	}

	public String getAddress() {
		return address;
	}

	// setters with validation (only for firstName, lastName, phone, and address)

	public void setFirstName(String firstName) {
		this.firstName = validateName(firstName, "First Name");
	}

	public void setLastName(String lastName) {
		this.lastName = validateName(lastName, "Last Name");
	}

	public void setPhone(String phone) {
		this.phone = validatePhone(phone);
	}

	public void setAddress(String address) {
		this.address = validateAddress(address);
	}

	// private helper method for validation
	private String validateId(String id) {
		// If statement to check input against requirements
		if (id == null || id.length() > MAX_ID_LENGTH) {
			// Exception given if requirements are not met
			throw new IllegalArgumentException(
					"Contact ID must not be null and must be " + MAX_ID_LENGTH + " characters or less.");
		}
		return id;
	}

	private String validateName(String name, String fieldName) {
		if (name == null || name.length() > MAX_NAME_LENGTH) {
			throw new IllegalArgumentException(
					fieldName + " must not be null and must be " + MAX_NAME_LENGTH + " characters or less.");
		}
		return name;
	}

	private String validatePhone(String phone) {
		if (phone == null || phone.length() != PHONE_LENGTH || !phone.matches("\\d+")) {
			throw new IllegalArgumentException(
					"Phone must be exactly " + PHONE_LENGTH + " digits and must not be null.");
		}
		return phone;
	}

	private String validateAddress(String address) {
		if (address == null || address.length() > MAX_ADDRESS_LENGTH) {
			throw new IllegalArgumentException(
					"Address must not be null and must be " + MAX_ADDRESS_LENGTH + " characters or less.");
		}
		return address;
	}
}