package main.java.model;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
	
	//HashMap to store task info (key: taskId, value: task object)
	private Map<String, Task> taskMap = new HashMap<>();
	
	//method to add a new task
	public void addTask(Task task) {
		//if statement to verify input meets requirements
		if (taskMap.containsKey(task.getTaskId())) {
			throw new IllegalArgumentException("Task ID already exists.");
		}
		//if requirements are met
		taskMap.put(task.getTaskId(), task);
	}
	
	//Method to delete tasks per task Id
	public void deleteTask(String taskId) {
		if (!taskMap.containsKey(taskId)) {
			throw new IllegalArgumentException("Task Id not found.");
		}
		taskMap.remove(taskId);
	}
	
	//Method to update fields per task Id
	public void updateTask (String taskId, String taskName, String taskDescription) {
		if (!taskMap.containsKey(taskId)) {
			throw new IllegalArgumentException("Task Id not found.");
		}
		Task task = taskMap.get(taskId);
		task.setTaskName(taskName);
		task.setTaskDescription(taskDescription);
	}

}
