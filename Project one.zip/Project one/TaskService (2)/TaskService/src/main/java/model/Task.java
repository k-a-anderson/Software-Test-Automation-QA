package main.java.model;

public class Task {
	
	//constants for validation
	private static final int MAX_TASKID_LENGTH = 10;
	private static final int MAX_TASKNAME_LENGTH = 20;
	private static final int MAX_TASKDESCRIPTION_LENGTH = 50;
	
	//attributes
	private final String taskId; //not able to be updated
	private String taskName;
	private String taskDescription;
	
	//Constructor
	public Task(String taskId, String taskName, String taskDescription) {
		
		this.taskId = validateId(taskId); //Cannot be updated later
		this.taskName = validateName(taskName);
		this.taskDescription = validateDescription(taskDescription);
	}
	
	//getters
	public String getTaskId() {
		return taskId;
	}
	
	public String getTaskName() {
		return taskName;
	}
	
	public String getTaskDescription() {
		return taskDescription;
	}
	
	//setters with validation (only for task name and description)
	public void setTaskName(String taskName) {
		this.taskName = validateName(taskName);
	}
	
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = validateDescription(taskDescription);
	}
	
	//private helper methods for validation
	private String validateId(String taskId) {
		if (taskId == null) {
			//exception given if requirements are not met
			throw new IllegalArgumentException("Task Id must not be null.");
		}
		if (taskId.length() > MAX_TASKID_LENGTH) {
			throw new IllegalArgumentException("Task Id must not be longer than 10 characters.");
		}
		return taskId;
	}
	
	private String validateName(String taskName) {
		if (taskName == null) {
			throw new IllegalArgumentException("Task Name must not be null.");
		}
		if (taskName.length() > MAX_TASKNAME_LENGTH) {
			throw new IllegalArgumentException("Task Name must not be longer than 20 characters.");
		}
		return taskName;
	}
	
	private String validateDescription(String taskDescription) {
		if (taskDescription == null) {
			throw new IllegalArgumentException("Task Description must not be null.");
		}
		if (taskDescription.length() > MAX_TASKDESCRIPTION_LENGTH) {
			throw new IllegalArgumentException("Task Description must not be longer than 50 characters.");
		}
		return taskDescription;
	}

}
