package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.java.model.Task;
import main.java.model.TaskService;

class TaskServiceTest {

	@Test
	//Test to add new task successfully
	void testAddTaskSuccessfully() {
	    TaskService service = new TaskService();
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    service.addTask(task);
	}
	
	@Test
	//Test for duplicate task Id
	void testAddDuplicateTaskId() {
		TaskService service = new TaskService();
	    Task task1 = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    Task task2 = new Task("12345", "Dishes", "Wash dishes this weekend.");
	    
	    service.addTask(task1);;
	    assertThrows(IllegalArgumentException.class,() -> {
	    	service.addTask(task2);
	    }, "Expected an exception when entering duplicate task Id.");
	}
	
	@Test
	//Test for deleting task per task Id successfully
	void testDeleteTaskSuccessfully () {
		TaskService service = new TaskService();
		Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
		service.addTask(task);
		
		service.deleteTask("12345");
	}
	
	@Test
	//test for deleting task unsuccessfully
	void testDeleteTaskUnuccessfully () {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class,() -> {
			service.deleteTask("invalid");
		},"Expected an exception when deleting an invalid task");
	}
	
	@Test
	//test for updating task description successfully
	void testUpdateTaskDescriptionSuccessfully() {
		TaskService service = new TaskService();
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    service.addTask(task);
	    
	    service.updateTask("12345", "Laundry", "Wash clothes");
	    assertEquals("Wash clothes", task.getTaskDescription());
	}
	
	@Test
	//Test for updating task description unsuccessfully(null)
	void testUpdateTaskDescriptionNull() {
		TaskService service = new TaskService();
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    service.addTask(task);
	    
	    assertThrows(IllegalArgumentException.class, () -> {
	        service.updateTask("12345", "Laundry", null);
	    }, "Expected an exception when setting task description to null");
	}
	
	@Test
	//test for updating task description unsuccessfully(too long)
	void testUpdateTaskDescriptionTooLong() {
		TaskService service = new TaskService();
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    service.addTask(task);
	    
	    assertThrows(IllegalArgumentException.class, () -> {
	        service.updateTask("12345", "Laundry", "Test Description Is Too Long. This is an Example of a description being too long for an update.");
	    }, "Expected an exception when updating task description with over 50 characters");
	}
	
	@Test
	//test for updating task name successfully
	void testUpdateTaskNameSuccessfully() {
		TaskService service = new TaskService();
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    service.addTask(task);
	    
	    service.updateTask("12345", "Dishes", "Wash clothes this weekend.");
	    assertEquals("Dishes", task.getTaskName());
	}
	
	@Test
	//Test for updating task name unsuccessfully(null)
	void testUpdateTaskNameNull() {
		TaskService service = new TaskService();
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    service.addTask(task);
	    
	    assertThrows(IllegalArgumentException.class, () -> {
	        service.updateTask("12345", null, "Wash clothes this weekend.");
	    }, "Expected an exception when setting task name to null");
	}
	
	@Test
	//test for updating task name unsuccessfully(too long)
	void testUpdateTaskNameTooLong() {
		TaskService service = new TaskService();
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    service.addTask(task);
	    
	    assertThrows(IllegalArgumentException.class, () -> {
	        service.updateTask("12345", "This is a test name that is too long", "Wash clothes this weekend.");
	    },"Expected an exception when updating task name to over 20 characters");
	}
	    
}