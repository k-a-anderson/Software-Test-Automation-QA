package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.java.model.Task;

class TaskTest {

	@Test
	// Test for valid task ID
	void testValidTaskId() {
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    assertEquals("12345", task.getTaskId());
	}

	@Test
	// Test for valid task name
	void testValidTaskName() {
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    assertEquals("Laundry", task.getTaskName());
	}

	@Test
	// Test for valid task description
	void testValidTaskDescription() {
	    Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
	    assertEquals("Wash clothes this weekend.", task.getTaskDescription());
	}
	
	@Test
	//Test for null taskId
	void testTaskIdNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task (null, "Laundry", "Wash clothes this weekend.");
		}, "Expected an exception when using a null Task Id");
	}
	
	@Test
	//Test for taskId exceeding length
	void testTaskIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678900", "Laundry", "Wash clothes this weekend.");
		}, "Expected an exception when using entering a Task Id with more than 10 characters");
	}
	
	@Test
	//Test for null task name
	void testTaskNameNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task ("12345", null, "Wash clothes this weekend.");
		}, "Expected an exception when using a null Task Name");
	}
	
	@Test
	//test for taskName exceeding length
	void testTaskNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "Test Name Is Too Long", "Wash clothes this weekend.");
		}, "Expected an exception when entering a Task name longer than 20 characters");
	}
	
	@Test
	//test for null task description
	void testTaskDescriptionNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task ("12345", "Laundry", null);
		}, "Expected an exception when using a null Task description");
	}
	
	@Test
	//test for task description exceeding length
	void testTaskDescriptionTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "Laundry", "Wash clothes this weekend. Wash clothes this weekend.");
		}, "Expected an exception when entering a Task name longer than 50 characters");
	}
	
	//Tests for setters
	//Valid Updates
	
	@Test 
	//test for valid task name update
	void testSetTaskNameSuccessfully() {
		Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
		task.setTaskName("Dishes");
		assertEquals("Dishes", task.getTaskName());
	}
	
	@Test 
	//test for valid task description update
	void testSetTaskDescriptionSuccessfully() {
		Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
		task.setTaskDescription("Wash dishes this weekend");
		assertEquals("Wash dishes this weekend", task.getTaskDescription());
	}
	
	//Invalid updates
	
	@Test
	//test for invalid name update to null
	void testSetTaskNameNull() {
		Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
		assertThrows(IllegalArgumentException.class, () -> {
	        task.setTaskName(null);
	    },"Expected an exception when setting taskName to null");
	}
	
	@Test
	//test for invalid name update (too long)
	void testSetTaskNameInvalid() {
		Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
		assertThrows(IllegalArgumentException.class, () -> {
	        task.setTaskName("Test Name Is Too Long");
	    },"Expected an exception when updating task name to more than 20 characters");
	}
	
	@Test
	//Test for invalid task description update to null
	void testSetTaskDescriptionNull() {
		Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
		assertThrows(IllegalArgumentException.class, () -> {
	        task.setTaskDescription(null);
	    },"Expected an exception when setting task Description to null");
	}
	
	@Test
	//Test for invalid task description update (Too long)
	void testSetTaskDescriptionInvalid() {
		Task task = new Task("12345", "Laundry", "Wash clothes this weekend.");
		assertThrows(IllegalArgumentException.class, () -> {
	        task.setTaskDescription("Test Description Is Too Long. This is an Example of a description being too long for an update.");
	    },"Expected an exception when updating task Description to more than 50 characters");
	}
	
	
	//Edge case tests
	
	@Test
	// Test task ID with exactly 10 characters
	void testTaskIdMaxLength() {
	    Task task = new Task("1234567890", "Laundry", "Wash clothes this weekend.");
	    assertEquals("1234567890", task.getTaskId());
	}

	@Test
	// Test task name with exactly 20 characters
	void testTaskNameMaxLength() {
	    Task task = new Task("12345", "12345678901234567890", "Wash clothes this weekend.");
	    assertEquals("12345678901234567890", task.getTaskName());
	}

	@Test
	// Test task description with exactly 50 characters
	void testTaskDescriptionMaxLength() {
	    Task task = new Task("12345", "Laundry", "12345678901234567890123456789012345678901234567890");
	    assertEquals("12345678901234567890123456789012345678901234567890", task.getTaskDescription());
	}
}